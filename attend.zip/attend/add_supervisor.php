<?php
include 'db.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];

    if (!empty($name) && !empty($phone)) {
        $sql = "INSERT INTO supervisors (name, phone) VALUES ('$name', '$phone')";
        if ($conn->query($sql)) {
            echo "<script>alert('Supervisor added successfully!');</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "<script>alert('All fields are required!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Supervisor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-1">
    <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Intern Management</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Attendance</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="sorting_interns.php">Sort Interns</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_intern.php">Add Intern</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_supervisor.php">Add Supervisor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_data.php">View Data</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_attendance.php">View Attendance</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

    <h2 class="text-center">Add Supervisor</h2>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Supervisor Name</label>
            <input type="text" class="form-control" name="name" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Phone Number</label>
            <input type="text" class="form-control" name="phone" required>
        </div>
        <button type="submit" class="btn btn-success">Add Supervisor</button>
    </form>

</body>
</html>
