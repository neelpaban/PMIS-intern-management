<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    foreach ($_POST['attendance'] as $intern_id => $dates) {
        foreach ($dates as $date => $status) {
            // Check if attendance for this intern on this date already exists
            $checkQuery = "SELECT * FROM attendance WHERE intern_id = ? AND date = ?";
            $stmt = $conn->prepare($checkQuery);
            $stmt->bind_param("is", $intern_id, $date);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // If record exists, update it
                $updateQuery = "UPDATE attendance SET status = ? WHERE intern_id = ? AND date = ?";
                $updateStmt = $conn->prepare($updateQuery);
                $updateStmt->bind_param("sis", $status, $intern_id, $date);
                $updateStmt->execute();
            } else {
                // If record does not exist, insert new
                $insertQuery = "INSERT INTO attendance (intern_id, date, status) VALUES (?, ?, ?)";
                $insertStmt = $conn->prepare($insertQuery);
                $insertStmt->bind_param("iss", $intern_id, $date, $status);
                $insertStmt->execute();
            }
        }
    }

    // Redirect back to the attendance page
    header("Location: index.php?success=1");
    exit();
}
?>
