<?php
include 'db.php';

// Include PhpSpreadsheet library
require 'vendor/autoload.php'; // Make sure you have PhpSpreadsheet installed via Composer

// Get the month, year, and department from the URL parameters (defaults to current month, year, and all departments)
$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$department = isset($_GET['department']) ? $_GET['department'] : '';

// Get the number of days in the selected month
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);

// Fetch interns from database, optionally filter by department
$departmentCondition = $department ? "WHERE department = '$department'" : '';
$interns = $conn->query("SELECT * FROM interns $departmentCondition");

// Fetch attendance records for the selected month and year
$attendanceData = [];
$result = $conn->query("SELECT intern_id, DAY(date) as day, status FROM attendance WHERE MONTH(date) = '$month' AND YEAR(date) = '$year'");

while ($row = $result->fetch_assoc()) {
    $attendanceData[$row['intern_id']][$row['day']] = $row['status'];
}

// Fetch available months and years
$months = [
    '01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April',
    '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August',
    '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December'
];
$years = range(date('Y') - 5, date('Y'));

// Fetch unique departments from the interns table
$departmentsResult = $conn->query("SELECT DISTINCT department FROM interns");
$departments = [];
while ($row = $departmentsResult->fetch_assoc()) {
    $departments[] = $row['department'];
}

// Only process the export if the button is pressed
if (isset($_POST['export_excel'])) {
    // Create a new spreadsheet
    $spreadsheet = new PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set the headers
    $sheet->setCellValue('A1', 'Status');
    $sheet->setCellValue('B1', 'Unique ID');
    $sheet->setCellValue('C1', 'Intern Name');
    $sheet->setCellValue('D1', 'Department');

    // Add days to the header dynamically based on the selected month
    for ($i = 1; $i <= $days_in_month; $i++) {
        $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i + 4); // Starting from column E
        $sheet->setCellValue($colLetter . '1', $i); // Days in columns E onwards
    }

    // Add Total Absent and Stipend columns at the end
    $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($days_in_month + 5); // Total Absent column
    $sheet->setCellValue($colLetter . '1', 'Total Absent (A)');
    $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($days_in_month + 6); // Stipend column
    $sheet->setCellValue($colLetter . '1', 'Stipend');

    // Start populating data from row 2
    $rowNumber = 2;

    // Loop through each intern and populate data
    while ($intern = $interns->fetch_assoc()) {
        $totalAbsent = 0;
        $columnIndex = 5; // Start after Status, Unique ID, Intern Name, Department

        // Write the intern data
        $sheet->setCellValue('A' . $rowNumber, $intern['status']);
        $sheet->setCellValue('B' . $rowNumber, $intern['unique_id']);
        $sheet->setCellValue('C' . $rowNumber, $intern['name']);
        $sheet->setCellValue('D' . $rowNumber, $intern['department']);

        // Write the attendance for each day in the month
        for ($i = 1; $i <= $days_in_month; $i++) {
            $status = $attendanceData[$intern['id']][$i] ?? ''; // Check attendance data
            $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($columnIndex); // Convert column index to letter
            $sheet->setCellValue($colLetter . $rowNumber, $status);
            if ($status === 'A') {
                $totalAbsent++;
            }
            $columnIndex++;
        }

        // Write total absent and stipend at the end
        $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($columnIndex);
        $sheet->setCellValue($colLetter . $rowNumber, $totalAbsent); // Total Absent column
        $columnIndex++;
        
        $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($columnIndex);
        $perDayDeduction = 500 / $days_in_month;
        $stipend = 500 - ($perDayDeduction * $totalAbsent); // Calculate stipend
        $sheet->setCellValue($colLetter . $rowNumber, round($stipend, 2)); // Stipend column

        $rowNumber++;
    }

    // Set the header for download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="attendance_' . $months[$month] . '_' . $year . '.xlsx"');
    header('Cache-Control: max-age=0');

    // Write the file to PHP output
    $writer = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table th, .table td { text-align: center; }
        .present { background-color: #d4edda; }
        .cl { background-color: #fff3cd; }
        
        /* Red highlight for Absent (A) */
        .absent {
            background-color: #f8d7da;
            color: red;
        }

        /* Ensure columns are well-aligned */
        .attendance-table td {
            padding: 10px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Intern Management</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Attendance</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="sorting_interns.php">Sort Interns</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_intern.php">Add Intern</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_supervisor.php">Add Supervisor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_data.php">View Data</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_attendance.php">View Attendance</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Main Content -->
<div class="container mt-5">
    <h2 class="text-center">Attendance Chart - <?php echo $months[$month] . ' ' . $year; ?></h2>

    <!-- Export Button -->
    <form method="POST" class="d-flex justify-content-center mb-4">
        <button type="submit" name="export_excel" class="btn btn-success">Export to Excel</button>
    </form>
    
    <!-- Month, Year, and Department Selection Form -->
    <form method="GET" class="d-flex justify-content-center mb-4">
        <select name="month" class="form-select w-auto" onchange="this.form.submit()">
            <?php foreach ($months as $m => $month_name): ?>
                <option value="<?php echo $m; ?>" <?php echo ($m == $month) ? 'selected' : ''; ?>><?php echo $month_name; ?></option>
            <?php endforeach; ?>
        </select>
        <select name="year" class="form-select w-auto ms-3" onchange="this.form.submit()">
            <?php foreach ($years as $y): ?>
                <option value="<?php echo $y; ?>" <?php echo ($y == $year) ? 'selected' : ''; ?>><?php echo $y; ?></option>
            <?php endforeach; ?>
        </select>
        <select name="department" class="form-select w-auto ms-3" onchange="this.form.submit()">
            <option value="">All Departments</option>
            <?php foreach ($departments as $dept): ?>
                <option value="<?php echo $dept; ?>" <?php echo ($dept == $department) ? 'selected' : ''; ?>><?php echo $dept; ?></option>
            <?php endforeach; ?>
        </select>
    </form>
    
    <table class="table table-bordered attendance-table">
        <thead>
            <tr>
                <th>Status</th>
                <th>Unique ID</th>
                <th>Intern Name</th>
                <th>Department</th>
                <?php for ($i = 1; $i <= $days_in_month; $i++): ?>
                    <th><?php echo $i; ?></th>
                <?php endfor; ?>
                <th>Total Absent (A)</th>
                <th>Stipend</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $rowNumber = 2;
            while ($intern = $interns->fetch_assoc()):
                $totalAbsent = 0;
                $columnIndex = 2;
            ?>
            <tr>
                <td><?php echo $intern['status']; ?></td>
                <td><?php echo $intern['unique_id']; ?></td>
                <td><?php echo $intern['name']; ?></td>
                <td><?php echo $intern['department']; ?></td>
                <?php for ($i = 1; $i <= $days_in_month; $i++): 
                    $status = $attendanceData[$intern['id']][$i] ?? '';
                    ?>
                    <td class="<?php echo ($status == 'A') ? 'absent' : ''; ?>"><?php echo $status; ?></td>
                <?php 
                    if ($status == 'A') $totalAbsent++;
                    endfor;
                ?>
                <td><?php echo $totalAbsent; ?></td>
                <td><?php echo round(500 - (500 / $days_in_month * $totalAbsent), 2); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Bootstrap JS (optional) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
