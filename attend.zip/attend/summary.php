<?php
include 'db.php';

$interns = $conn->query("SELECT id, name FROM interns");

echo "<table class='table table-bordered'>
        <tr><th>Intern</th><th>Total P</th><th>Total A</th><th>Total CL</th></tr>";

while ($intern = $interns->fetch_assoc()) {
    $intern_id = $intern['id'];
    $result = $conn->query("SELECT status, COUNT(*) as count FROM attendance WHERE intern_id='$intern_id' GROUP BY status");

    $totalP = $totalA = $totalCL = 0;
    while ($row = $result->fetch_assoc()) {
        if ($row['status'] == 'P') $totalP = $row['count'];
        if ($row['status'] == 'A') $totalA = $row['count'];
        if ($row['status'] == 'CL') $totalCL = $row['count'];
    }

    echo "<tr>
            <td>{$intern['name']}</td>
            <td>$totalP</td>
            <td>$totalA</td>
            <td>$totalCL</td>
          </tr>";
}

echo "</table>";
?>
