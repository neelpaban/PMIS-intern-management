<?php
include 'db.php';

// Fetch supervisors from the database
$supervisors = $conn->query("SELECT * FROM supervisors");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $unique_id = $_POST['unique_id'];  // Capture the Unique ID entered by the user
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $department = $_POST['department'];
    $gender = $_POST['gender'];
    $supervisor_id = $_POST['supervisor'];

    // Insert the new intern into the database, including the unique ID
    $stmt = $conn->prepare("INSERT INTO interns (unique_id, name, phone, department, gender, supervisor_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $unique_id, $name, $phone, $department, $gender, $supervisor_id);

    if ($stmt->execute()) {
        echo "<script>alert('Intern added successfully!');</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Intern</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Intern Management</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Attendance</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="sorting_interns.php">Sort Interns</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_intern.php">Add Intern</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_supervisor.php">Add Supervisor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_data.php">View Data</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_attendance.php">View Attendance</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Main Content -->
<div class="container mt-5">
    <h2>Add Intern</h2>

    <form action="add_intern.php" method="POST">
        <div class="mb-3">
            <label for="unique_id" class="form-label">Unique Intern ID</label>
            <input type="text" class="form-control" id="unique_id" name="unique_id" required>
        </div>

        <div class="mb-3">
            <label for="name" class="form-label">Intern Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>

        <div class="mb-3">
            <label for="phone" class="form-label">Phone Number</label>
            <input type="text" class="form-control" id="phone" name="phone" required>
        </div>

        <div class="mb-3">
            <label for="department" class="form-label">Department</label>
            <input type="text" class="form-control" id="department" name="department" required>
        </div>

        <div class="mb-3">
            <label for="gender" class="form-label">Gender</label>
            <select class="form-select" id="gender" name="gender" required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="supervisor" class="form-label">Supervisor</label>
            <select class="form-select" id="supervisor" name="supervisor" required>
                <option value="">Select Supervisor</option>
                <?php while ($supervisor = $supervisors->fetch_assoc()): ?>
                    <option value="<?php echo $supervisor['id']; ?>"><?php echo $supervisor['name']; ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Add Intern</button>
    </form>
</div>

</body>
</html>
