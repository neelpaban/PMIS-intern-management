<?php
include 'db.php';

// Get the selected supervisor and status from the URL parameters (default: no filter)
$supervisorFilter = isset($_GET['supervisor']) ? $_GET['supervisor'] : '';
$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';

// Fetch supervisors for the supervisor filter
$supervisorsResult = $conn->query("SELECT * FROM supervisors");

// Fetch distinct status values from the interns table for the status filter
$statusResult = $conn->query("SELECT DISTINCT status FROM interns WHERE status IS NOT NULL");

// Modify the query to optionally filter by supervisor and status
$supervisorCondition = $supervisorFilter ? "WHERE i.supervisor_id = '$supervisorFilter'" : '';
$statusCondition = $statusFilter ? " AND i.status = '$statusFilter'" : '';
$interns = $conn->query("SELECT i.*, s.name AS supervisor_name FROM interns i 
                         LEFT JOIN supervisors s ON i.supervisor_id = s.id $supervisorCondition $statusCondition");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Intern Management</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Attendance</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="sorting_interns.php">Sort Interns</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_intern.php">Add Intern</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_supervisor.php">Add Supervisor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_data.php">View Data</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_attendance.php">View Attendance</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

    <h2 class="text-center">View Data</h2>

    <h4>Supervisors</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Phone</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $supervisorsResult->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h4>Interns</h4>
    <!-- Add Supervisor and Status filters inside Interns section -->
    <form method="GET" class="mb-3">
        <div class="row">
            <div class="col-md-6">
                <label for="supervisor" class="form-label">Filter by Supervisor:</label>
                <select name="supervisor" id="supervisor" class="form-select" onchange="this.form.submit()">
                    <option value="">All Supervisors</option>
                    <?php 
                    // Reset supervisors query to populate dropdown
                    $supervisorsResult = $conn->query("SELECT * FROM supervisors");
                    while ($row = $supervisorsResult->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>" <?php echo ($row['id'] == $supervisorFilter) ? 'selected' : ''; ?>>
                            <?php echo $row['name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="col-md-6">
                <label for="status" class="form-label">Filter by Status:</label>
                <select name="status" id="status" class="form-select" onchange="this.form.submit()">
                    <option value="">All Statuses</option>
                    <?php 
                    // Loop through distinct status values fetched from the database
                    while ($statusRow = $statusResult->fetch_assoc()): ?>
                        <option value="<?php echo $statusRow['status']; ?>" <?php echo ($statusRow['status'] == $statusFilter) ? 'selected' : ''; ?>>
                            <?php echo $statusRow['status']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
        </div>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Unique ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Department</th>
                <th>Supervisor</th>
                <th>Status</th> <!-- New column for status -->
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $interns->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['unique_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['department']; ?></td>
                    <td><?php echo $row['supervisor_name']; ?></td>
                    <td><?php echo $row['status']; ?></td> <!-- Display the status -->
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</body>
</html>
