<?php
include 'db.php';

// Get month, year, and department from GET parameters, default to current month, year, and all departments
$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$department = isset($_GET['department']) ? $_GET['department'] : '';

// Get the number of days in the selected month
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);

// Fetch interns from database, optionally filter by department
$departmentCondition = $department ? "WHERE department = '$department'" : '';
$interns = $conn->query("SELECT * FROM interns $departmentCondition");

// Fetch attendance records for the selected month and year
$attendanceData = [];
$result = $conn->query("SELECT intern_id, DAY(date) as day, status FROM attendance WHERE MONTH(date) = '$month' AND YEAR(date) = '$year'");

while ($row = $result->fetch_assoc()) {
    $attendanceData[$row['intern_id']][$row['day']] = $row['status'];
}

// Fetch available years (last 5 years)
$years = range(date('Y') - 5, date('Y'));

// Fetch available months
$months = [
    '01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April',
    '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August',
    '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December'
];

// Fetch distinct departments from interns table
$departmentsResult = $conn->query("SELECT DISTINCT department FROM interns");
$departments = [];
while ($row = $departmentsResult->fetch_assoc()) {
    $departments[] = $row['department'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intern Attendance System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
    font-family: 'Arial', sans-serif;
    background-color: #f7f7f7;
}

.navbar {
    background-color: #343a40;
}

.navbar-brand {
    font-size: 1.8rem;
    font-weight: bold;
}

.table {
    margin-top: 30px;
    border-radius: 8px;
    background-color: white;
    box-shadow: 0px 2px 15px rgba(0, 0, 0, 0.1);
}

.table th, .table td {
    text-align: center;
    padding: 12px;
}

.table th {
    background-color: #007bff;
    color: white;
}

.table tr:nth-child(even) {
    background-color: #f2f2f2;
}

.table tr:hover {
    background-color: #e9e9e9;
}

.attendance-select {
    width: 60px;
    text-align: center;
    font-weight: bold;
    border-radius: 4px;
}

.filter-form select {
    font-size: 1rem;
    padding: 10px;
    border-radius: 4px;
}

.filter-form {
    margin-bottom: 20px;
    display: flex;
    justify-content: center;
    gap: 15px;
}

.filter-form select:focus {
    outline: none;
    border-color: #007bff;
}

.container {
    max-width: 1100px;
    margin-left: 0; /* Shift to left */
    margin-right: auto; /* Maintain proper right alignment */
    padding: 30px 15px;
}

.header-text {
    margin-bottom: 40px;
    text-align: center;
    font-size: 2rem;
    font-weight: bold;
    color: #333;
}

.btn-save {
    margin-top: 20px;
    background-color: #28a745;
    color: white;
    border: none;
    padding: 12px 20px;
    font-size: 1rem;
    cursor: pointer;
    border-radius: 5px;
}

.btn-save:hover {
    background-color: #218838;
}

.navbar-nav .nav-item .nav-link {
    font-size: 1.1rem;
    font-weight: 500;
}

.navbar-nav .nav-item .nav-link.active {
    color: #f1f1f1;
}

.navbar-nav .nav-item .nav-link:hover {
    color: #f1f1f1;
}

    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Intern Management by nei.lkelvin</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Attendance</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="sorting_interns.php">Sort Interns</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_intern.php">Add Intern</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_supervisor.php">Add Supervisor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_data.php">View Data</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_attendance.php">View Attendance</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Main Content -->
<div class="container mt-5">
    <h2 class="text-center">Intern Attendance - <?php echo $months[$month] . ' ' . $year; ?></h2>
    
    <!-- Month, Year, and Department Selection Form -->
    <form method="GET" class="d-flex justify-content-center mb-4">
        <select name="month" class="form-select w-auto" onchange="this.form.submit()">
            <?php foreach ($months as $m => $month_name): ?>
                <option value="<?php echo $m; ?>" <?php echo ($m == $month) ? 'selected' : ''; ?>><?php echo $month_name; ?></option>
            <?php endforeach; ?>
        </select>
        <select name="year" class="form-select w-auto ms-3" onchange="this.form.submit()">
            <?php foreach ($years as $y): ?>
                <option value="<?php echo $y; ?>" <?php echo ($y == $year) ? 'selected' : ''; ?>><?php echo $y; ?></option>
            <?php endforeach; ?>
        </select>
        <select name="department" class="form-select w-auto ms-3" onchange="this.form.submit()">
            <option value="">All Departments</option>
            <?php foreach ($departments as $dept): ?>
                <option value="<?php echo $dept; ?>" <?php echo ($dept == $department) ? 'selected' : ''; ?>><?php echo $dept; ?></option>
            <?php endforeach; ?>
        </select>
    </form>
    
    <!-- Attendance Form -->
    <form action="save_attendance.php" method="POST">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Unique ID</th>
                    <th>Intern Name</th>
                    <th>Department</th>
                    <?php for ($i = 1; $i <= $days_in_month; $i++): ?>
                        <th><?php echo $i; ?></th>
                    <?php endfor; ?>
                    <th>Total P</th>
                    <th>Total A</th>
                    <th>Total CL</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($intern = $interns->fetch_assoc()): ?>
                    <?php 
                        $totalP = 0; 
                        $totalA = 0; 
                        $totalCL = 0; 
                    ?>
                    <tr>
                        <td><?php echo $intern['unique_id']; ?></td>
                        <td><?php echo $intern['name']; ?></td>
                        <td><?php echo $intern['department']; ?></td>
                        <?php for ($i = 1; $i <= $days_in_month; $i++): 
                            $status = $attendanceData[$intern['id']][$i] ?? ''; 
                            if ($status === 'P') $totalP++;
                            if ($status === 'A') $totalA++;
                            if ($status === 'CL') $totalCL++;
                        ?>
                            <td>
                                <select name="attendance[<?php echo $intern['id']; ?>][<?php echo $year . '-' . $month . '-' . str_pad($i, 2, '0', STR_PAD_LEFT); ?>]" 
                                    class="form-select attendance-select">
                                    <option value="P" <?php echo ($status == 'P') ? 'selected' : ''; ?>>P</option>
                                    <option value="A" <?php echo ($status == 'A') ? 'selected' : ''; ?>>A</option>
                                    <option value="CL" <?php echo ($status == 'CL') ? 'selected' : ''; ?>>CL</option>
                                </select>
                            </td>
                        <?php endfor; ?>
                        <td class="totalP"><?php echo $totalP; ?></td>
                        <td class="totalA"><?php echo $totalA; ?></td>
                        <td class="totalCL"><?php echo $totalCL; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-success">Save Attendance</button>
    </form>
</div>

<script>
    document.querySelectorAll('.attendance-select').forEach(select => {
        select.addEventListener('change', function() {
            updateTotals();
        });
    });

    function updateTotals() {
        document.querySelectorAll("tbody tr").forEach(row => {
            let totalP = row.querySelectorAll("option[value='P']:checked").length;
            let totalA = row.querySelectorAll("option[value='A']:checked").length;
            let totalCL = row.querySelectorAll("option[value='CL']:checked").length;
            
            row.querySelector(".totalP").textContent = totalP;
            row.querySelector(".totalA").textContent = totalA;
            row.querySelector(".totalCL").textContent = totalCL;
        });
    }
</script>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

</body>
</html>
