<?php
include 'db.php';

// Check if the unique ID is provided
if (isset($_POST['unique_id'])) {
    $unique_id = $_POST['unique_id'];

    // Fetch intern details by unique_id
    $result = $conn->query("SELECT * FROM interns WHERE unique_id = '$unique_id'");
    $intern = $result->fetch_assoc();

    // If intern is found, handle the status and supervisor update
    if ($intern) {
        if (isset($_POST['status'])) {
            $new_status = $_POST['status'];
            $conn->query("UPDATE interns SET status = '$new_status' WHERE unique_id = '$unique_id'");
            $message = "Status updated successfully!";
            // Fetch updated intern details
            $result = $conn->query("SELECT * FROM interns WHERE unique_id = '$unique_id'");
            $intern = $result->fetch_assoc();
        }

        if (isset($_POST['supervisor_id'])) {
            $new_supervisor_id = $_POST['supervisor_id'];
            $conn->query("UPDATE interns SET supervisor_id = '$new_supervisor_id' WHERE unique_id = '$unique_id'");
            $message = "Supervisor updated successfully!";
            // Fetch updated intern details
            $result = $conn->query("SELECT * FROM interns WHERE unique_id = '$unique_id'");
            $intern = $result->fetch_assoc();
        }
    } else {
        $message = "No intern found with the provided Unique ID.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sort Interns</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Intern Management</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Attendance</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="sorting_interns.php">Sort Interns</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_intern.php">Add Intern</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_supervisor.php">Add Supervisor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_data.php">View Data</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="view_attendance.php">View Attendance</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Main Content -->
<div class="container mt-5">
    <h2 class="text-center">Sort Interns</h2>

    <!-- Unique ID Search Form -->
    <form method="POST" class="d-flex justify-content-center mb-4">
        <input type="text" name="unique_id" class="form-control w-25" placeholder="Enter Unique ID" required>
        <button type="submit" class="btn btn-primary ms-2">Search</button>
    </form>

    <?php if (isset($message)): ?>
        <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>

    <?php if (isset($intern)): ?>
        <h4 class="text-center">Intern Details</h4>
        <table class="table table-bordered">
            <tr>
                <th>Unique ID</th>
                <td><?php echo $intern['unique_id']; ?></td>
            </tr>
            <tr>
                <th>Intern Name</th>
                <td><?php echo $intern['name']; ?></td>
            </tr>
            <tr>
                <th>Department</th>
                <td><?php echo $intern['department']; ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td>
                    <form method="POST">
                        <input type="hidden" name="unique_id" value="<?php echo $intern['unique_id']; ?>">
                        <select name="status" class="form-select w-auto">
                            <option value="Active" <?php echo ($intern['status'] == 'Active') ? 'selected' : ''; ?>>Active</option>
                            <option value="Dropout" <?php echo ($intern['status'] == 'Dropout') ? 'selected' : ''; ?>>Dropout</option>
                            <option value="Sabbatical" <?php echo ($intern['status'] == 'Sabbatical') ? 'selected' : ''; ?>>Sabbatical</option>
                            <option value="Absconding Behaviour" <?php echo ($intern['status'] == 'Absconding Behaviour') ? 'selected' : ''; ?>>Absconding Behaviour</option>
                            <option value="Absconding Reminder 1" <?php echo ($intern['status'] == 'Absconding Reminder 1') ? 'selected' : ''; ?>>Absconding Reminder 1</option>
                            <option value="Absconding Reminder 2" <?php echo ($intern['status'] == 'Absconding Reminder 2') ? 'selected' : ''; ?>>Absconding Reminder 2</option>
                        </select>
                        <button type="submit" class="btn btn-success mt-2">Update Status</button>
                    </form>
                </td>
            </tr>
            <tr>
                <th>Supervisor</th>
                <td>
                    <form method="POST">
                        <input type="hidden" name="unique_id" value="<?php echo $intern['unique_id']; ?>">
                        <select name="supervisor_id" class="form-select w-auto">
                            <option value="">Select Supervisor</option>
                            <?php
                                // Fetch all supervisors
                                $supervisors = $conn->query("SELECT * FROM supervisors");
                                while ($supervisor = $supervisors->fetch_assoc()) {
                                    echo "<option value='".$supervisor['id']."'".($intern['supervisor_id'] == $supervisor['id'] ? ' selected' : '').">".$supervisor['name']."</option>";
                                }
                            ?>
                        </select>
                        <button type="submit" class="btn btn-success mt-2">Update Supervisor</button>
                    </form>
                </td>
            </tr>
        </table>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
